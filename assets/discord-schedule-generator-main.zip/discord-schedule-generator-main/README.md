# discord-schedule-generator
Useful tool to generate your Twitch schedule such that the generate outcome displays in user's local timezone. 

# URL
https://discord-schedule-generator.netlify.app/ 

# Design Choices & Features
- TODO
